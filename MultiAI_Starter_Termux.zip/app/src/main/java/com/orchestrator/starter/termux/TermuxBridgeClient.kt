package com.orchestrator.starter.termux

import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

data class ExecResult(
    val ok: Boolean,
    val exitCode: Int,
    val stdout: String,
    val stderr: String
)

class TermuxBridgeClient(
    private val baseUrl: String,
    private val token: String
) {
    private val http = OkHttpClient()
    private val json = "application/json".toMediaType()

    fun ping(callback: (Boolean, String) -> Unit) {
        val req = Request.Builder()
            .url("$baseUrl/ping")
            .addHeader("Authorization", "Bearer $token")
            .get()
            .build()
        http.newCall(req).enqueue(object: Callback {
            override fun onFailure(call: Call, e: IOException) { callback(false, e.message ?: "network error") }
            override fun onResponse(call: Call, r: Response) {
                r.use { callback(r.isSuccessful, it.body?.string() ?: "") }
            }
        })
    }

    fun fetchLogs(lines: Int = 200, callback: (Boolean, String) -> Unit) {
        val req = Request.Builder()
            .url("$baseUrl/logs?tail=$lines")
            .addHeader("Authorization", "Bearer $token")
            .get()
            .build()
        http.newCall(req).enqueue(object: Callback {
            override fun onFailure(call: Call, e: IOException) { callback(false, e.message ?: "net error") }
            override fun onResponse(call: Call, r: Response) { r.use { callback(r.isSuccessful, it.body?.string().orEmpty()) } }
        })
    }

    fun exec(cmd: String, timeoutSec: Int = 60, callback: (ExecResult) -> Unit) {
        val payload = JSONObject().apply { put("cmd", cmd); put("timeoutSec", timeoutSec) }.toString()
        val body = payload.toRequestBody(json)
        val req = Request.Builder()
            .url("$baseUrl/exec")
            .addHeader("Authorization", "Bearer $token")
            .post(body)
            .build()
        http.newCall(req).enqueue(object: Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback(ExecResult(false, -1, "", e.message ?: "network error"))
            }
            override fun onResponse(call: Call, r: Response) {
                r.use {
                    val txt = it.body?.string().orEmpty()
                    if (!it.isSuccessful) {
                        callback(ExecResult(false, r.code, "", txt)); return
                    }
                    try {
                        val obj = JSONObject(txt)
                        callback(ExecResult(
                            ok = obj.optBoolean("ok", false),
                            exitCode = obj.optInt("exitCode", -1),
                            stdout = obj.optString("stdout", ""),
                            stderr = obj.optString("stderr", "")
                        ))
                    } catch (_: Exception) {
                        callback(ExecResult(true, 0, txt, ""))
                    }
                }
            }
        })
    }
}
