package com.orchestrator.starter.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.orchestrator.starter.databinding.ActivityTermuxSettingsBinding
import com.orchestrator.starter.storage.SecureStore
import com.orchestrator.starter.termux.TermuxBridgeClient

class TermuxSettingsActivity : AppCompatActivity() {
    private lateinit var b: ActivityTermuxSettingsBinding
    private lateinit var store: SecureStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTermuxSettingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        store = SecureStore(this)

        b.etUrl.setText(store.getTermuxUrl() ?: "http://127.0.0.1:8337")
        b.etToken.setText(store.getTermuxToken() ?: "")

        b.btnSave.setOnClickListener {
            store.setTermuxUrl(b.etUrl.text.toString().trim())
            store.setTermuxToken(b.etToken.text.toString().trim())
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            finish()
        }

        b.btnTest.setOnClickListener {
            val url = b.etUrl.text.toString().trim()
            val tok = b.etToken.text.toString().trim()
            if (tok.isEmpty()) { Toast.makeText(this, "Set token first", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val client = TermuxBridgeClient(url, tok)
            client.ping { ok, msg ->
                runOnUiThread {
                    Toast.makeText(this, if (ok) "pong" else "failed: $msg", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
