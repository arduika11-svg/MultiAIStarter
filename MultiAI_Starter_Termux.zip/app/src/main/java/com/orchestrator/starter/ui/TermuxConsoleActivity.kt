package com.orchestrator.starter.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.orchestrator.starter.R
import com.orchestrator.starter.storage.SecureStore
import com.orchestrator.starter.termux.TermuxBridgeClient
import java.io.File

class TermuxConsoleActivity : AppCompatActivity() {
    private lateinit var client: TermuxBridgeClient
    private lateinit var tvLogs: android.widget.TextView
    private lateinit var tvStatus: android.widget.TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_termux_console)
        tvLogs = findViewById(R.id.tvLogs)
        tvStatus = findViewById(R.id.tvStatus)

        val store = SecureStore(this)
        val baseUrl = store.getTermuxUrl() ?: "http://127.0.0.1:8337"
        val token   = store.getTermuxToken() ?: ""
        if (token.isBlank()) { finish(); return }

        client = TermuxBridgeClient(baseUrl, token)

        findViewById<android.widget.Button>(R.id.btnPing).setOnClickListener { ping() }
        findViewById<android.widget.Button>(R.id.btnRefresh).setOnClickListener { loadLogs() }
        findViewById<android.widget.Button>(R.id.btnExport).setOnClickListener { exportLogs() }
        findViewById<android.widget.Button>(R.id.btnStopBridge).setOnClickListener { killBridge() }

        ping()
        loadLogs()
    }

    private fun ping() {
        client.ping { ok, _ -> runOnUiThread { tvStatus.text = if (ok) "Status: ONLINE" else "Status: OFFLINE" } }
    }

    private fun loadLogs() {
        client.fetchLogs(400) { ok, txt ->
            runOnUiThread {
                if (!ok) Toast.makeText(this, "Logs fetch failed", Toast.LENGTH_SHORT).show()
                tvLogs.text = txt
                (tvLogs.parent as? android.widget.ScrollView)?.post {
                    (tvLogs.parent as android.widget.ScrollView).fullScroll(android.view.View.FOCUS_DOWN)
                }
            }
        }
    }

    private fun exportLogs() {
        val f = File(filesDir, "termux_logs.txt")
        f.writeText(tvLogs.text.toString())
        Toast.makeText(this, "Saved: ${f.absolutePath}", Toast.LENGTH_LONG).show()
    }

    private fun killBridge() {
        client.exec("__KILL_BRIDGE__", timeoutSec = 3) { r ->
            runOnUiThread { Toast.makeText(this, if (r.ok) "Bridge stopping…" else "Kill failed", Toast.LENGTH_SHORT).show() }
        }
    }
}
