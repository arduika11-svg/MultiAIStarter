package com.orchestrator.starter.storage

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import com.orchestrator.starter.net.Provider

class SecureStore(ctx: Context) {
    private val masterKey = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
    private val sp = EncryptedSharedPreferences.create(
        "secure_store", masterKey, ctx,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun save(p: Provider, key: String?, base: String?) {
        sp.edit().putString("${p.name}_KEY", key ?: "")
            .putString("${p.name}_BASE", base ?: "")
            .apply()
    }
    fun getKey(p: Provider)  = sp.getString("${p.name}_KEY", "") ?: ""
    fun getBase(p: Provider) = sp.getString("${p.name}_BASE", "")?.ifBlank { null }

    // Termux bridge
    fun setTermuxUrl(url: String?) { sp.edit().putString("TERMUX_URL", url ?: "").apply() }
    fun getTermuxUrl(): String? = sp.getString("TERMUX_URL", "")?.ifBlank { null }
    fun setTermuxToken(token: String?) { sp.edit().putString("TERMUX_TOKEN", token ?: "").apply() }
    fun getTermuxToken(): String? = sp.getString("TERMUX_TOKEN", "")?.ifBlank { null }
}
