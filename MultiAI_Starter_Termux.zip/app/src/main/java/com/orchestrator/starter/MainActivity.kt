package com.orchestrator.starter

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.orchestrator.starter.databinding.ActivityMainBinding
import com.orchestrator.starter.net.Provider
import com.orchestrator.starter.ui.ChatActivity
import com.orchestrator.starter.ui.ConnectionsActivity
import com.orchestrator.starter.ui.TermuxConsoleActivity
import com.orchestrator.starter.ui.TermuxSettingsActivity
import com.orchestrator.starter.ui.UnifiedChatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnCfgOpenAI.setOnClickListener { openConnections(Provider.OpenAI) }
        b.btnCfgGrok.setOnClickListener   { openConnections(Provider.Grok) }
        b.btnCfgGemini.setOnClickListener { openConnections(Provider.Gemini) }

        b.btnChatOpenAI.setOnClickListener { openChat(Provider.OpenAI) }
        b.btnChatGrok.setOnClickListener   { openChat(Provider.Grok) }
        b.btnChatGemini.setOnClickListener { openChat(Provider.Gemini) }

        b.btnChatUnified.setOnClickListener {
            startActivity(Intent(this, UnifiedChatActivity::class.java))
        }

        // Long-press any cfg button to open Termux settings quickly
        listOf(b.btnCfgOpenAI, b.btnCfgGrok, b.btnCfgGemini).forEach { view ->
            view.setOnLongClickListener {
                startActivity(Intent(this, TermuxSettingsActivity::class.java))
                true
            }
        }

        // Termux console
        b.btnTermuxConsole.setOnClickListener {
            startActivity(Intent(this, TermuxConsoleActivity::class.java))
        }
    }

    private fun openConnections(p: Provider) {
        startActivity(Intent(this, ConnectionsActivity::class.java).putExtra("focus", p.name))
    }

    private fun openChat(p: Provider) {
        startActivity(Intent(this, ChatActivity::class.java).putExtra("provider", p.name))
    }
}
