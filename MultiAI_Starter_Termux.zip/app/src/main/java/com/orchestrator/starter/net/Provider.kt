package com.orchestrator.starter.net
enum class Provider { OpenAI, Grok, Gemini }
