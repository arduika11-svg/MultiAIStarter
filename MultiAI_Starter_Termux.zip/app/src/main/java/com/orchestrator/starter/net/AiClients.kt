package com.orchestrator.starter.net

import com.google.gson.JsonObject
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class AiClients(private val key: String, private val baseUrl: String, private val provider: Provider) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()

    fun ask(prompt: String): Result<String> = runCatching {
        when (provider) {
            Provider.OpenAI -> askOpenAI(prompt)
            Provider.Grok   -> askGrok(prompt)
            Provider.Gemini -> askGemini(prompt)
        }
    }

    private fun askOpenAI(prompt: String): String {
        val url = (if (baseUrl.isBlank()) "https://api.openai.com" else baseUrl) + "/v1/chat/completions"
        val payload = "{"model":"gpt-4o-mini","messages":[{"role":"user","content":" + json(prompt) + "}]}"
        val body = payload.toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url(url)
            .addHeader("Authorization", "Bearer $key")
            .post(body).build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("OpenAI ${'$'}{r.code}")
            return r.body!!.string()
        }
    }

    private fun askGrok(prompt: String): String {
        val url = (if (baseUrl.isBlank()) "https://api.x.ai" else baseUrl) + "/v1/chat/completions"
        val payload = "{"model":"grok-beta","messages":[{"role":"user","content":" + json(prompt) + "}]}"
        val body = payload.toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url(url)
            .addHeader("Authorization", "Bearer $key")
            .post(body).build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Grok ${'$'}{r.code}")
            return r.body!!.string()
        }
    }

    private fun askGemini(prompt: String): String {
        val base = if (baseUrl.isBlank()) "https://generativelanguage.googleapis.com" else baseUrl
        val url = "$base/v1beta/models/gemini-1.5-flash:generateContent?key=$key"
        val payload = "{"contents":[{"parts":[{"text":" + json(prompt) + "}]}]}"
        val body = payload.toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url(url).post(body).build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Gemini ${'$'}{r.code}")
            return r.body!!.string()
        }
    }

    private fun json(s: String) = JsonObject().apply { addProperty("x", s) }.get("x").toString()
}
