package com.orchestrator.starter.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.orchestrator.starter.R

class MessagesAdapter(private val data: List<Pair<String,String>>) :
    RecyclerView.Adapter<MessagesAdapter.VH>() {

    class VH(v: View): RecyclerView.ViewHolder(v) {
        val role: TextView = v.findViewById(R.id.tvRole)
        val text: TextView = v.findViewById(R.id.tvText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.row_message, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val (r,t) = data[position]
        holder.role.text = r
        holder.text.text = t
    }

    override fun getItemCount() = data.size
}
