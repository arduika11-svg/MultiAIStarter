package com.orchestrator.starter.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.orchestrator.starter.databinding.ActivityConnectionsBinding
import com.orchestrator.starter.net.Provider
import com.orchestrator.starter.storage.SecureStore

class ConnectionsActivity : AppCompatActivity() {
    private lateinit var b: ActivityConnectionsBinding
    private lateinit var store: SecureStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityConnectionsBinding.inflate(layoutInflater)
        setContentView(b.root)
        store = SecureStore(this)

        b.etOpenAiKey.setText(store.getKey(Provider.OpenAI))
        b.etOpenAiBase.setText(store.getBase(Provider.OpenAI) ?: "")
        b.etGrokKey.setText(store.getKey(Provider.Grok))
        b.etGrokBase.setText(store.getBase(Provider.Grok) ?: "")
        b.etGeminiKey.setText(store.getKey(Provider.Gemini))
        b.etGeminiBase.setText(store.getBase(Provider.Gemini) ?: "")

        when (intent.getStringExtra("focus")) {
            Provider.OpenAI.name -> b.etOpenAiKey.requestFocus()
            Provider.Grok.name   -> b.etGrokKey.requestFocus()
            Provider.Gemini.name -> b.etGeminiKey.requestFocus()
        }

        b.btnSave.setOnClickListener {
            store.save(Provider.OpenAI, b.etOpenAiKey.text.toString(), b.etOpenAiBase.text.toString())
            store.save(Provider.Grok,   b.etGrokKey.text.toString(),   b.etGrokBase.text.toString())
            store.save(Provider.Gemini, b.etGeminiKey.text.toString(), b.etGeminiBase.text.toString())
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            finish()
        }

        b.btnTest.setOnClickListener {
            val ok = listOfNotNull(
                b.etOpenAiKey.text?.takeIf { it.isNotBlank() }?.let { "OpenAI" },
                b.etGrokKey.text?.takeIf { it.isNotBlank() }?.let { "Grok" },
                b.etGeminiKey.text?.takeIf { it.isNotBlank() }?.let { "Gemini" },
            ).joinToString(", ")
            Toast.makeText(this, if (ok.isEmpty()) "No keys" else "Configured: $ok", Toast.LENGTH_SHORT).show()
        }
    }
}
