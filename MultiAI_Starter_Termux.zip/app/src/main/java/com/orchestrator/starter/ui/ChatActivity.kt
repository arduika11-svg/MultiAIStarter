package com.orchestrator.starter.ui

import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.orchestrator.starter.databinding.ActivityChatBinding
import com.orchestrator.starter.net.AiClients
import com.orchestrator.starter.net.Provider
import com.orchestrator.starter.storage.SecureStore
import com.orchestrator.starter.termux.TermuxBridgeClient
import kotlin.concurrent.thread

class ChatActivity : AppCompatActivity() {
    private lateinit var b: ActivityChatBinding
    private lateinit var p: Provider
    private val msgs = mutableListOf<Pair<String,String>>()
    private val adapter by lazy { MessagesAdapter(msgs) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityChatBinding.inflate(layoutInflater)
        setContentView(b.root)

        p = Provider.valueOf(intent.getStringExtra("provider")!!)
        b.tvTitle.text = "Chat • ${p.name}"
        b.rv.layoutManager = LinearLayoutManager(this)
        b.rv.adapter = adapter

        val store = SecureStore(this)
        val key = store.getKey(p)
        val base = store.getBase(p) ?: ""
        val termuxUrl = store.getTermuxUrl()
        val termuxTok = store.getTermuxToken()

        val client = AiClients(key, base, p)

        b.btnSend.setOnClickListener {
            val prompt = b.et.text.toString().trim()
            if (prompt.isEmpty()) return@setOnClickListener
            b.et.setText("")
            add("you", prompt)
            thread {
                val res = client.ask(prompt).fold(onSuccess = { it }, onFailure = { "Error: ${it.message}" })
                runOnUiThread { add(p.name, res) }
            }
        }

        b.btnRunTermux.setOnClickListener {
            val candidate = extractCmd(b.et.text.toString()).orEmpty()
            if (candidate.isBlank()) {
                AlertDialog.Builder(this).setTitle("No command")
                    .setMessage("Type a shell command or include ```bash``` block.")
                    .setPositiveButton("OK", null).show()
                return@setOnClickListener
            }
            if (termuxUrl.isNullOrBlank() || termuxTok.isNullOrBlank()) {
                AlertDialog.Builder(this).setTitle("Bridge not configured")
                    .setMessage("Open Termux Bridge settings and set URL + Token.")
                    .setPositiveButton("OK", null).show()
                return@setOnClickListener
            }
            val bridge = TermuxBridgeClient(termuxUrl, termuxTok)
            add("termux", "Running: $candidate")
            bridge.exec(candidate, timeoutSec = 90) { r ->
                runOnUiThread {
                    val txt = if (r.ok) (r.stdout.ifBlank { "(no output)" })
                              else "Error (code ${r.exitCode}): ${r.stderr}"
                    add("termux", txt)
                }
            }
        }
    }

    private fun add(role: String, text: String) {
        msgs.add(role to text)
        adapter.notifyItemInserted(msgs.size-1)
        b.rv.scrollToPosition(msgs.size-1)
    }

    private fun extractCmd(text: String): String? {
        val regex = Regex("```(bash|sh)?\s*([\s\S]*?)```", RegexOption.IGNORE_CASE)
        val m = regex.find(text)
        return (m?.groups?.get(2)?.value ?: text).trim().ifBlank { null }
    }
}
