# MultiAI_Starter_Termux

- Main screen: config logos (OpenAI/Grok/Gemini), 3 per-provider chats, and Unified Chat.
- Termux integration:
  - **Termux Settings**: set Bridge URL + Secret token.
  - **Termux Console**: live logs (/logs), ping, export, kill bridge.
  - In Chat screens: **Run in Termux** runs the message (or ```bash``` block).

## Termux local bridge (quick start)
In Termux:
```bash
pkg update -y && pkg install -y python
curl -fsSL https://example.invalid/termux_bridge.py -o ~/termux_bridge.py  # (or copy from docs)
export BRIDGE_TOKEN="YOUR_SECRET_TOKEN"
export BRIDGE_ALLOW="bash,sh,python,python3,pip,git,ls,cat,curl,wget,grep,sed,awk,make,node,npm,go,gradle"
export BRIDGE_PORT=8337
python ~/termux_bridge.py
```

Then set the same URL/token in the app (Termux Settings).

## Build (GitHub Actions)
Push and run **Build Android (Debug APK)**. Artifact: `app-debug.apk`.
